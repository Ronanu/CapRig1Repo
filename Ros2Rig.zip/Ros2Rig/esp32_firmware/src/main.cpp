#include <Arduino.h>
#include <micro_ros_arduino.h>
#include <rcl/rcl.h>
#include <rclc/rclc.h>
#include <std_msgs/msg/string.h>
#include <rmw_microros/rmw_microros.h>
#include "esp_timer.h"

rcl_publisher_t pub_dummy;
rcl_publisher_t pub_echo;
rcl_subscription_t sub_cmd;

rcl_node_t node;
rclc_support_t support;
rcl_allocator_t allocator;
rclc_executor_t executor;

static uint64_t get_epoch_ns_or_zero() {
  uint64_t ns = 0;
  if (rmw_uros_epoch_nanos(&ns) == RMW_RET_OK) return ns;
  return 0;
}

void cmd_callback(const void *msgin) {
  auto *in = (const std_msgs__msg__String *)msgin;
  const char *cmd = in && in->data.data ? in->data.data : "";

  int64_t t_local_us = esp_timer_get_time();
  uint64_t t_epoch_ns = get_epoch_ns_or_zero();

  // Build a small JSON echo payload
  char buf[256];
  snprintf(buf, sizeof(buf),
           "{\"cmd\":\"%s\",\"t_local_us\":%lld,\"t_epoch_ns\":%llu}",
           cmd, (long long)t_local_us, (unsigned long long)t_epoch_ns);

  std_msgs__msg__String out;
  out.data.data = (char*)buf;
  out.data.size = strnlen(buf, sizeof(buf));
  out.data.capacity = out.data.size + 1;
  rcl_publish(&pub_echo, &out, NULL);
}

void setup() {
  Serial.begin(115200);
  delay(2000);

  // Transport: SERIAL by default. For UDP, replace with set_microros_wifi_transports(...)
  set_microros_serial_transports(Serial);

  allocator = rcl_get_default_allocator();
  rclc_support_init(&support, 0, NULL, &allocator);
  rclc_node_init_default(&node, "esp32_node", "", &support);

  rclc_publisher_init_default(
    &pub_dummy, &node,
    ROSIDL_GET_MSG_TYPE_SUPPORT(std_msgs, msg, String),
    "/esp/dummy");

  rclc_publisher_init_default(
    &pub_echo, &node,
    ROSIDL_GET_MSG_TYPE_SUPPORT(std_msgs, msg, String),
    "/gui/echo");

  rclc_subscription_init_default(
    &sub_cmd, &node,
    ROSIDL_GET_MSG_TYPE_SUPPORT(std_msgs, msg, String),
    "/gui/cmd");

  rclc_executor_init(&executor, &support.context, 1, &allocator);
  rclc_executor_add_subscription(&executor, &sub_cmd, nullptr, &cmd_callback, ON_NEW_DATA);
}

void loop() {
  static uint32_t seq = 0;
  static unsigned long last_ms = 0;

  rclc_executor_spin_some(&executor, RCL_MS_TO_NS(1));

  unsigned long now = millis();
  if (now - last_ms >= 20) { // 50 Hz
    last_ms = now;

    int64_t t_local_us = esp_timer_get_time();
    uint64_t t_epoch_ns = get_epoch_ns_or_zero();
    float val = sinf((seq % 360) * 3.1415926f / 180.0f);

    char buf[256];
    snprintf(buf, sizeof(buf),
             "{\"seq\":%lu,\"val\":%.6f,\"t_local_us\":%lld,\"t_epoch_ns\":%llu}",
             (unsigned long)seq++, val, (long long)t_local_us, (unsigned long long)t_epoch_ns);

    std_msgs__msg__String msg;
    msg.data.data = (char*)buf;
    msg.data.size = strnlen(buf, sizeof(buf));
    msg.data.capacity = msg.data.size + 1;
    rcl_publish(&pub_dummy, &msg, NULL);
  }
}
