#include "ProtobufComm.hpp"
#include <pb_encode.h>
#include <pb_decode.h>
#include "pb.h"

// FreeRTOS
#include <freertos/FreeRTOS.h>
#include <freertos/queue.h>
#include <freertos/task.h>

ProtobufComm::ProtobufComm(Stream& stream)
  : serial(stream) {}

void ProtobufComm::begin(uint8_t taskCore, UBaseType_t taskPrio, uint16_t queueLen) {
  if (!txQueue_) {
    txQueue_ = xQueueCreate(queueLen, sizeof(TxPacket));
  }
  if (txQueue_ && !txTask_) {
    xTaskCreatePinnedToCore(
      ProtobufComm::txTaskTrampoline,
      "ProtoTx",
      4096,
      this,
      taskPrio,
      &txTask_,
      taskCore
    );
  }
}

bool ProtobufComm::receive(ToEsp32& out) {
  // Need at least length prefix
  if (serial.available() < 2) return false;

  // Read big-endian length
  uint16_t len = ((uint16_t)serial.read() << 8) | serial.read();
  if (len == 0 || len > 128) return false;

  uint8_t buffer[128];
  size_t i = 0;
  // Read payload with short timeout guard (avoid infinite loop)
  const unsigned long tStart = micros();
  while (i < len) {
    if (serial.available()) {
      buffer[i++] = (uint8_t)serial.read();
    } else {
      if ((micros() - tStart) > 20000) { // ~20 ms guard
        return false;
      }
      // Briefly yield to other tasks
      vTaskDelay(1);
    }
  }

  pb_istream_t istream = pb_istream_from_buffer(buffer, len);
  return pb_decode(&istream, ToEsp32_fields, &out);
}

bool ProtobufComm::encodeToPacket(const FromEsp32& msg, TxPacket& pkt) {
  pb_ostream_t ostream = pb_ostream_from_buffer(pkt.data, sizeof(pkt.data));
  if (!pb_encode(&ostream, FromEsp32_fields, &msg)) {
    return false;
  }
  pkt.len = static_cast<uint16_t>(ostream.bytes_written);
  return true;
}

void ProtobufComm::writePacket(const TxPacket& pkt) {
  // Write big-endian length
  serial.write((uint8_t)(pkt.len >> 8));
  serial.write((uint8_t)(pkt.len & 0xFF));

  // Write payload (handle partial writes)
  size_t off = 0;
  while (off < pkt.len) {
    int n = serial.write(pkt.data + off, pkt.len - off);
    if (n > 0) {
      off += static_cast<size_t>(n);
    } else {
      vTaskDelay(1);
    }
  }
}

void ProtobufComm::txTaskTrampoline(void* pv) {
  static_cast<ProtobufComm*>(pv)->txTaskLoop();
}

void ProtobufComm::txTaskLoop() {
  TxPacket pkt;
  for (;;) {
    if (xQueueReceive(txQueue_, &pkt, portMAX_DELAY) == pdTRUE) {
      writePacket(pkt);
    }
  }
}

bool ProtobufComm::send(const FromEsp32& msg) {
  TxPacket pkt;
  if (!encodeToPacket(msg, pkt)) {
    return false;
  }

  if (!txQueue_) {
    // Synchronous fallback
    writePacket(pkt);
    return true;
  }

  // Non-blocking enqueue. If full, drop oldest and retry to avoid blocking producers.
  if (xQueueSend(txQueue_, &pkt, 0) == pdPASS) {
    return true;
  } else {
    TxPacket dropOld;
    xQueueReceive(txQueue_, &dropOld, 0);
    return xQueueSend(txQueue_, &pkt, 0) == pdPASS;
  }
}

void ProtobufComm::sendDebug(const char* text) {
  FromEsp32 msg = FromEsp32_init_zero;
  msg.timestamp = micros();
  msg.which_response = FromEsp32_debug_tag;
  strncpy(msg.response.debug.text, text, sizeof(msg.response.debug.text) - 1);
  msg.response.debug.text[sizeof(msg.response.debug.text) - 1] = '\0';
  (void)send(msg);
}

uint32_t ProtobufComm::calculateChecksum(uint32_t sensor_id, float value) {
  union { float f; uint32_t u; } conv = { value };
  return sensor_id ^ conv.u;
}
