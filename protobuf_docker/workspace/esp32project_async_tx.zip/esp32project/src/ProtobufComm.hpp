#ifndef PROTOBUF_COMM_HPP
#define PROTOBUF_COMM_HPP

#include <Arduino.h>
#include "messages_nanopb.pb.h"

// Forward declarations from nanopb
// (headers are included in .cpp to keep this header lean)

/**
 * @brief Minimal, clean protobuf comms with asynchronous TX buffering.
 *
 * Usage:
 *   ProtobufComm comm(Serial);
 *   void setup() {
 *     Serial.begin(115200);
 *     comm.begin(1 /* core */, 1 /* prio */, 16 /* queueLen */);
 *   }
 *   comm.send(msg); // non-blocking enqueue
 */
class ProtobufComm {
public:
  explicit ProtobufComm(Stream& stream);

  // Start asynchronous TX worker. If not called, send() falls back to synchronous write.
  void begin(uint8_t taskCore = 1, UBaseType_t taskPrio = 1, uint16_t queueLen = 16);

  // Receive one message if available. Returns true on success.
  bool receive(ToEsp32& out);

  // Enqueue a message for sending. Returns true on success.
  bool send(const FromEsp32& msg);

  // Convenience helpers preserved from original interface
  void sendDebug(const char* text);
  uint32_t calculateChecksum(uint32_t sensor_id, float value);

private:
  Stream& serial;

  // -------- TX queue types --------
  struct TxPacket {
    uint16_t len = 0;
    uint8_t  data[128];
  };

  // FreeRTOS handles (kept private)
  void txTaskLoop();
  static void txTaskTrampoline(void* pv);

  void writePacket(const TxPacket& pkt);

  // Encodes msg into pkt.data/len. Returns false on encode error.
  bool encodeToPacket(const FromEsp32& msg, TxPacket& pkt);

  // Initialized by begin(); nullptr means "no async mode"
  QueueHandle_t txQueue_ = nullptr;
  TaskHandle_t  txTask_  = nullptr;
};

#endif // PROTOBUF_COMM_HPP
