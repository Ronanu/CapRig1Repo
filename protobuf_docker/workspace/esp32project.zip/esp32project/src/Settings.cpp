#include "Settings.hpp"
#include <Preferences.h>

static const char* kNs = "appcfg";

SettingsManager& SettingsManager::instance() {
  static SettingsManager inst;
  return inst;
}

SettingsManager::SettingsManager() {
  mtx_ = xSemaphoreCreateMutex();
}

Settings SettingsManager::get() {
  xSemaphoreTake(mtx_, portMAX_DELAY);
  Settings copy = s_;
  xSemaphoreGive(mtx_);
  return copy;
}

void SettingsManager::set(const Settings& in) {
  Settings v = in;
  if (v.action_state > 3) v.action_state = 3;
  xSemaphoreTake(mtx_, portMAX_DELAY);
  s_ = v;
  last_change_us_ = micros();
  xSemaphoreGive(mtx_);
}

void SettingsManager::toProto(SystemSettings& out) {
  Settings c = get();
  out.current_signal_selection_state = c.current_signal_selection_state;
  out.action_state = c.action_state;
}

void SettingsManager::fromProto(SystemSettings& in) {
  Settings c = get();
  c.current_signal_selection_state = in.current_signal_selection_state;
  c.action_state = in.action_state;
  set(c);
}

void SettingsManager::load() {
  Preferences p;
  if (p.begin(kNs, true)) {
    Settings cur;
    cur.current_signal_selection_state = p.getBool("css", false);
    cur.action_state = p.getUInt("act", 0);
    p.end();
    set(cur);
  }
}

void SettingsManager::saveNow() {
  Settings cur = get();
  Preferences p;
  if (p.begin(kNs, false)) {
    p.putBool("css", cur.current_signal_selection_state);
    p.putUInt("act", cur.action_state);
    p.end();
  }
}

void SettingsManager::saveDebounced() {
  xSemaphoreTake(mtx_, portMAX_DELAY);
  last_change_us_ = micros();
  xSemaphoreGive(mtx_);
}

void SettingsManager::tick() {
  const unsigned long now = micros();
  bool do_save = false;

  xSemaphoreTake(mtx_, portMAX_DELAY);
  if (last_change_us_ != 0 && (now - last_change_us_) > SAVE_DEBOUNCE_US) {
    do_save = true;
    last_change_us_ = 0;
  }
  xSemaphoreGive(mtx_);

  if (do_save) saveNow();
}
