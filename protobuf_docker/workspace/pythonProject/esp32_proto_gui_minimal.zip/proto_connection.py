from __future__ import annotations
import time
import random
import threading
from log import logger
from proto_serial_client import ProtoSerialClient
from proto_runtime import ProtoRuntime

class ReconnectSupervisor:
    """
    Orchestrates ProtoSerialClient with automatic reconnects.
    - Exponential backoff with jitter
    - Link up/down callbacks
    - Periodic keepalive ping
    - RX inactivity timeout → restart link
    """
    def __init__(self, port: str, baudrate: int, runtime: ProtoRuntime,
                 backoff_min: float = 0.5, backoff_max: float = 8.0,
                 ack_timeout: float = 0.3, total_timeout: float = 1.2,
                 keepalive_s: float = 3.0, rx_timeout_s: float = 10.0) -> None:
        self.port = port
        self.baud = baudrate
        self.runtime = runtime
        self.backoff_min = backoff_min
        self.backoff_max = backoff_max
        self.ack_timeout = ack_timeout
        self.total_timeout = total_timeout
        self.keepalive_s = keepalive_s
        self.rx_timeout_s = rx_timeout_s

        self._stop = threading.Event()
        self._th = threading.Thread(target=self._loop, daemon=True)
        self.client: ProtoSerialClient | None = None

    def start(self):
        self._th.start()

    def stop(self):
        self._stop.set()
        try:
            if self.client:
                self.client.stop()
        except Exception as e:
            logger.debug(f"stop(): client stop error: {e}")
        self._th.join(timeout=2.0)

    # Callbacks from client
    def _on_up(self):
        logger.info("🔌 Link UP")
        # bind client into runtime
        self.runtime.client = self.client
        # optional hello
        try:
            self.runtime.ping(self.ack_timeout, self.total_timeout)
        except Exception as e:
            logger.warning(f"Ping after reconnect failed: {e}")

    def _on_down(self):
        logger.warning("⚠️  Link DOWN")

    def _loop(self):
        delay = self.backoff_min
        while not self._stop.is_set():
            try:
                logger.info(f"🔄 Connecting {self.port} @ {self.baud} ...")
                c = ProtoSerialClient(self.port, self.baud)
                c.set_runtime(self.runtime)
                c.set_link_callbacks(on_up=self._on_up, on_down=self._on_down)
                c.start_listener()
                self.client = c
                logger.info("✅ Connected, listener running")
                # keepalive / watchdog
                last_keepalive = 0.0
                while not self._stop.is_set() and c.is_connected():
                    now = time.monotonic()
                    # keepalive ping
                    if now - last_keepalive >= self.keepalive_s:
                        try:
                            self.runtime.ping(self.ack_timeout, self.total_timeout)
                        except Exception as e:
                            logger.warning(f"keepalive ping failed: {e}")
                        last_keepalive = now
                    # inactivity watchdog (no RX for too long)
                    if (now - c.last_rx) > self.rx_timeout_s:
                        logger.warning(f"RX inactivity > {self.rx_timeout_s}s → restarting link")
                        break
                    time.sleep(0.2)
                logger.warning("Listener stopped or stop requested")
            except Exception as e:
                logger.error(f"Connection attempt failed: {e}")

            if self._stop.is_set():
                break
            # backoff
            jitter = 0.2 * delay * (random.random() - 0.5)  # ±10%
            wait_s = max(self.backoff_min, min(self.backoff_max, delay + jitter))
            logger.info(f"⏳ Reconnect in {wait_s:.2f}s")
            time.sleep(wait_s)
            delay = min(self.backoff_max, max(self.backoff_min, delay * 2.0))
