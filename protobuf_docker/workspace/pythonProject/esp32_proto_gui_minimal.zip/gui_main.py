import threading
import time
import tkinter as tk
from tkinter import ttk, messagebox

from log import logger
from messages_pb2 import SystemSettings
from proto_runtime import ProtoRuntime
from proto_connection import ReconnectSupervisor

PORT = 'COM4'   # anpassen
BAUDRATE = 230400

class TkLogHandler:
    """Minimal thread-safe logger sink into a Tkinter Text widget."""
    def __init__(self, text: tk.Text):
        import logging, queue
        self.text = text
        self.queue = queue.Queue()
        self.handler = logging.Handler()
        self.handler.emit = self._emit  # monkey-patch emit
        logging.getLogger().addHandler(self.handler)
        # also hook project logger
        logger.addHandler(self.handler)
        self.text.after(100, self._drain)

    def _emit(self, record):
        import logging
        try:
            s = logging.getLogger().handlers[0].format(record)
        except Exception:
            s = f"{record.levelname}: {record.getMessage()}"
        self.queue.put(s)

    def _drain(self):
        try:
            while True:
                line = self.queue.get_nowait()
                self.text.insert('end', line + "\n")
                self.text.see('end')
        except Exception:
            pass
        self.text.after(100, self._drain)


class App(tk.Tk):
    def __init__(self):
        super().__init__()
        self.title("ESP32 Proto Link")
        self.geometry("820x520")
        self.configure(padx=10, pady=10)

        # runtime + supervisor
        self.runtime = ProtoRuntime(client=None)
        self.sup = ReconnectSupervisor(PORT, BAUDRATE, self.runtime)

        # UI
        self._build_ui()

        # Start link
        self.sup.start()
        self._tick()

    def _build_ui(self):
        # Status frame
        f_status = ttk.Frame(self)
        f_status.pack(fill='x', pady=(0,8))

        self.lbl_state = ttk.Label(f_status, text="State: connecting...", font=("Segoe UI", 11, "bold"))
        self.lbl_state.pack(side='left')

        self.lbl_stats = ttk.Label(f_status, text="")
        self.lbl_stats.pack(side='right')

        # Command frame
        f_cmd = ttk.LabelFrame(self, text="Commands")
        f_cmd.pack(fill='x', pady=(0,8))

        ttk.Button(f_cmd, text="Ping", command=self._do_ping).pack(side='left', padx=4, pady=6)
        ttk.Button(f_cmd, text="Get Settings", command=self._do_get).pack(side='left', padx=4, pady=6)

        # Settings inputs
        f_set = ttk.Frame(f_cmd)
        f_set.pack(side='left', padx=12)
        self.var_css = tk.BooleanVar(value=False)
        ttk.Checkbutton(f_set, text="current_signal_selection_state", variable=self.var_css).grid(row=0, column=0, sticky='w')
        ttk.Label(f_set, text="action_state:").grid(row=1, column=0, sticky='w', pady=(6,0))
        self.var_action = tk.IntVar(value=0)
        self.spin_action = ttk.Spinbox(f_set, from_=0, to=3, textvariable=self.var_action, width=5)
        self.spin_action.grid(row=1, column=1, sticky='w', padx=(6,0), pady=(6,0))

        ttk.Button(f_cmd, text="Set Settings", command=self._do_set).pack(side='left', padx=12, pady=6)

        # Log frame
        f_log = ttk.LabelFrame(self, text="Log")
        f_log.pack(fill='both', expand=True)

        self.txt_log = tk.Text(f_log, height=18, wrap='word', state='normal')
        self.txt_log.pack(fill='both', expand=True)

        try:
            TkLogHandler(self.txt_log)  # mirror logger into text
        except Exception:
            pass

        # Footer
        f_footer = ttk.Frame(self)
        f_footer.pack(fill='x', pady=(8,0))
        ttk.Button(f_footer, text="Quit", command=self._on_quit).pack(side='right')

    def _on_quit(self):
        try:
            self.sup.stop()
        except Exception:
            pass
        self.destroy()

    # --- helpers ---
    def _run_bg(self, fn, *args):
        def _wrap():
            try:
                fn(*args)
            except Exception as e:
                logger.error(f"Command error: {e}")
        t = threading.Thread(target=_wrap, daemon=True)
        t.start()

    # --- command handlers ---
    def _do_ping(self):
        if not self.sup.client:
            messagebox.showwarning("Not connected", "No link yet.")
            return
        self._run_bg(self.runtime.ping)

    def _do_get(self):
        if not self.sup.client:
            messagebox.showwarning("Not connected", "No link yet.")
            return
        self._run_bg(self.runtime.get_settings)

    def _do_set(self):
        if not self.sup.client:
            messagebox.showwarning("Not connected", "No link yet.")
            return
        s = SystemSettings()
        s.current_signal_selection_state = bool(self.var_css.get())
        s.action_state = int(self.var_action.get())
        self._run_bg(self.runtime.set_settings, s)

    # --- periodic UI refresh ---
    def _tick(self):
        c = self.sup.client
        if c and c.is_connected():
            age_rx = time.monotonic() - getattr(c, "last_rx", time.monotonic())
            self.lbl_state.configure(text="State: CONNECTED ✅")
            self.lbl_stats.configure(text=f"RX age: {age_rx:0.2f}s   TX bytes: {c.bytes_tx}   RX bytes: {c.bytes_rx}")
        else:
            self.lbl_state.configure(text="State: CONNECTING…")
            self.lbl_stats.configure(text="")
        self.after(300, self._tick)


if __name__ == "__main__":
    app = App()
    app.mainloop()
