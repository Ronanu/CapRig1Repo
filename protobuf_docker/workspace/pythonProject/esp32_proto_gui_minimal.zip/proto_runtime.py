"""
High‑level Protobuf Runtime for ESP32 link.
- RequestManager: tracks command/response lifecycles with ACK + total timeouts
- Simplified: sample messages are ignored here (no loss detection)
"""
from __future__ import annotations
import threading
import time
from dataclasses import dataclass, field
from enum import Enum, auto
from typing import Dict, Optional, Set

from log import logger

# --- Proto message imports ---
try:
    from messages_pb2 import FromEsp32, SystemSettings  # type: ignore
except Exception:  # pragma: no cover
    FromEsp32 = object  # shim for type hints
    SystemSettings = object


class RespKind(Enum):
    ACK = auto()
    INFO = auto()
    SETTINGS = auto()
    ERROR = auto()
    DEBUG = auto()
    SAMPLE = auto()
    OTHER = auto()


@dataclass
class RequestState:
    seq: int
    expect: Set[RespKind]
    ack_timeout_s: float
    total_timeout_s: float
    created_ts: float = field(default_factory=time.monotonic)
    got: Set[RespKind] = field(default_factory=set)
    info_message: Optional[str] = None
    error_text: Optional[str] = None
    settings: Optional[SystemSettings] = None
    ack_seen: bool = False
    event: threading.Event = field(default_factory=threading.Event)


class RequestManager:
    """Track outstanding requests by seq and fulfill expectations with timeouts."""

    def __init__(self) -> None:
        self._lock = threading.Lock()
        self._pending: Dict[int, RequestState] = {}

    def register(self, seq: int, expect: Set[RespKind], ack_timeout_s: float, total_timeout_s: float) -> None:
        with self._lock:
            if seq in self._pending:
                logger.warning(f"register(): seq {seq} already pending — overwriting")
            self._pending[seq] = RequestState(seq, set(expect), ack_timeout_s, total_timeout_s)
            logger.debug(f"Registered request seq={seq} expect={[k.name for k in expect]}")

    def notify(self, msg: FromEsp32) -> None:
        kind = self._classify(msg)
        seq = int(getattr(msg, 'seq', 0))
        with self._lock:
            st = self._pending.get(seq)
        if st is None:
            # stray or unsolicited
            logger.debug(f"notify(): unsolicited {kind.name} seq={seq}")
            return

        changed = False
        if kind == RespKind.ACK:
            st.ack_seen = True
            st.got.add(RespKind.ACK)
            changed = True
        elif kind == RespKind.INFO:
            st.info_message = getattr(msg.info, 'message', None)
            st.got.add(RespKind.INFO)
            changed = True
        elif kind == RespKind.SETTINGS:
            st.settings = msg.settings
            st.got.add(RespKind.SETTINGS)
            changed = True
        elif kind == RespKind.ERROR:
            st.error_text = getattr(msg.error, 'error', None)
            st.got.add(RespKind.ERROR)
            changed = True
        elif kind == RespKind.DEBUG:
            txt = getattr(msg.debug, 'text', None)
            if RespKind.INFO in st.expect and st.info_message is None:
                st.info_message = txt
                st.got.add(RespKind.INFO)
                changed = True

        if changed:
            logger.debug(f"notify(): seq={seq} got={[k.name for k in st.got]}")
            if st.expect.issubset(st.got):
                st.event.set()

    def wait(self, seq: int) -> RequestState:
        """Block for ACK then for all expected messages; return final state."""
        with self._lock:
            st = self._pending.get(seq)
        if st is None:
            raise RuntimeError(f"wait(): seq {seq} not registered")

        # Phase 1: ACK deadline
        ack_deadline = st.created_ts + st.ack_timeout_s
        while time.monotonic() < ack_deadline and not st.ack_seen:
            if st.event.wait(timeout=0.02):
                if st.ack_seen:
                    break
        if not st.ack_seen:
            logger.warning(f"ACK timeout for seq={seq}")

        # Phase 2: total deadline
        total_deadline = st.created_ts + st.total_timeout_s
        while time.monotonic() < total_deadline:
            if st.expect.issubset(st.got):
                break
            st.event.wait(timeout=0.02)

        with self._lock:
            self._pending.pop(seq, None)
        return st

    @staticmethod
    def _classify(msg: FromEsp32) -> RespKind:
        try:
            if msg.HasField("ack"):
                return RespKind.ACK
            if msg.HasField("info"):
                return RespKind.INFO
            if msg.HasField("settings"):
                return RespKind.SETTINGS
            if msg.HasField("error"):
                return RespKind.ERROR
            if msg.HasField("debug"):
                return RespKind.DEBUG
            if msg.HasField("sample"):
                return RespKind.SAMPLE
        except Exception:
            pass
        for name in ("ack","info","settings","error","debug","sample"):
            if hasattr(msg, name):
                return {
                    "ack": RespKind.ACK,
                    "info": RespKind.INFO,
                    "settings": RespKind.SETTINGS,
                    "error": RespKind.ERROR,
                    "debug": RespKind.DEBUG,
                    "sample": RespKind.SAMPLE,
                }[name]
        return RespKind.OTHER


class ProtoRuntime:
    """Glue: wire RequestManager to a transport (ProtoSerialClient)."""

    def __init__(self, client) -> None:
        self.client = client
        self.rm = RequestManager()

    # --- inbound path ---
    def ingest(self, msg: FromEsp32) -> None:
        kind = RequestManager._classify(msg)
        if kind == RespKind.SAMPLE:
            # Ignore samples here to keep the client lean & stable
            return
        self.rm.notify(msg)

    # --- high-level requests (blocking convenience) ---
    def ping(self, ack_timeout=0.3, total_timeout=1.2):
        if not self.client:
            raise RuntimeError("No client bound to runtime")
        seq = self.client.send_ping(return_seq=True)
        self.rm.register(seq, {RespKind.ACK, RespKind.INFO}, ack_timeout, total_timeout)
        st = self.rm.wait(seq)
        ok = st.ack_seen and ({RespKind.ACK, RespKind.INFO} - st.got == set())
        if not ok:
            missing = {RespKind.ACK, RespKind.INFO} - st.got
            logger.warning(f"ping() incomplete: missing={[m.name for m in missing]}")
        else:
            logger.info(f"ping() ok: info='{st.info_message}'")
        return st

    def get_settings(self, ack_timeout=0.3, total_timeout=1.2):
        if not self.client:
            raise RuntimeError("No client bound to runtime")
        seq = self.client.send_get_settings(return_seq=True)
        self.rm.register(seq, {RespKind.ACK, RespKind.SETTINGS}, ack_timeout, total_timeout)
        st = self.rm.wait(seq)
        ok = st.ack_seen and ({RespKind.ACK, RespKind.SETTINGS} - st.got == set())
        if not ok:
            missing = {RespKind.ACK, RespKind.SETTINGS} - st.got
            logger.warning(f"get_settings() incomplete: missing={[m.name for m in missing]}")
        else:
            logger.info("get_settings() ok")
        return st

    def set_settings(self, new_settings: SystemSettings, ack_timeout=0.3, total_timeout=1.2):
        if not self.client:
            raise RuntimeError("No client bound to runtime")
        seq = self.client.send_set_settings(new_settings, return_seq=True)
        self.rm.register(seq, {RespKind.ACK, RespKind.SETTINGS}, ack_timeout, total_timeout)
        st = self.rm.wait(seq)
        ok = st.ack_seen and ({RespKind.ACK, RespKind.SETTINGS} - st.got == set())
        if not ok:
            missing = {RespKind.ACK, RespKind.SETTINGS} - st.got
            logger.warning(f"set_settings() incomplete: missing={[m.name for m in missing]}")
        else:
            if st.info_message:
                logger.info(f"set_settings() ok: info='{st.info_message}'")
            else:
                logger.info("set_settings() ok")
        return st
