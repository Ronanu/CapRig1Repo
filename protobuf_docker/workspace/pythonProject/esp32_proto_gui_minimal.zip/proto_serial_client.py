import threading
import serial
import struct
import time
from typing import Optional, Callable

from log import logger
from messages_pb2 import ToEsp32, FromEsp32, SystemSettings

_MAX_FRAME = 128  # must match firmware

class ProtoSerialClient:
    def __init__(self, port, baudrate=115200, seq_start=1):
        self.port = port
        self.baudrate = baudrate
        self._seq = seq_start
        self.ser = serial.Serial(port, baudrate, timeout=0.1)
        self.running = False
        self.listener_thread = threading.Thread(target=self.listen, daemon=True)
        self.runtime = None  # set via set_runtime()
        self._on_up: Optional[Callable[[], None]] = None
        self._on_down: Optional[Callable[[], None]] = None
        self._tx_lock = threading.Lock()

        # stats & liveness
        now = time.monotonic()
        self.last_rx = now
        self.last_tx = now
        self.bytes_rx = 0
        self.bytes_tx = 0

        logger.info(f"ProtoSerialClient created for {port} @ {baudrate}")

        # internal rx buffer for robust framing
        self._rxbuf = bytearray()

    # --- hooks ---
    def set_runtime(self, runtime):
        self.runtime = runtime

    def set_link_callbacks(self, on_up=None, on_down=None):
        self._on_up = on_up
        self._on_down = on_down

    def is_connected(self) -> bool:
        try:
            return self.running and self.ser is not None and self.ser.is_open
        except Exception:
            return False

    # --- sequence ---
    def _next_seq(self):
        s = self._seq
        self._seq = 1 if s >= 0xFFFFFFFF else s + 1
        return s

    # --- lifecycle ---
    def start_listener(self):
        if self.running:
            logger.debug("start_listener(): already running")
            return
        self.running = True
        if not self.listener_thread.is_alive():
            self.listener_thread = threading.Thread(target=self.listen, daemon=True)
            self.listener_thread.start()
        # report link up
        if self._on_up:
            try:
                self._on_up()
            except Exception as e:
                logger.debug(f"on_up callback error: {e}")
        logger.info("Listener started")

    def stop(self):
        self.running = False
        try:
            if self.listener_thread.is_alive():
                self.listener_thread.join(timeout=1.0)
        except Exception as e:
            logger.debug(f"stop(): join error: {e}")
        try:
            if self.ser and self.ser.is_open:
                self.ser.close()
        except Exception as e:
            logger.debug(f"stop(): close error: {e}")
        logger.info("Link closed")

    # --- framing ---
    def _write_framed(self, payload: bytes):
        length = len(payload)
        if length > _MAX_FRAME:
            raise ValueError(f"Message too long (>{_MAX_FRAME} bytes)")
        header = struct.pack(">H", length)
        with self._tx_lock:
            self.ser.write(header + payload)
            self.bytes_tx += 2 + length
            self.last_tx = time.monotonic()

    def _feed_and_parse(self):
        """Consume self._rxbuf and yield complete protobuf messages."""
        msgs = []
        buf = self._rxbuf
        # try to parse multiple frames per chunk
        while True:
            if len(buf) < 2:
                break
            length = struct.unpack(">H", buf[:2])[0]
            if length == 0 or length > _MAX_FRAME:
                # desync: drop one byte and retry
                del buf[0:1]
                continue
            if len(buf) < 2 + length:
                break
            frame = bytes(buf[2:2+length])
            del buf[:2+length]
            # try to parse as protobuf
            msg = FromEsp32()
            try:
                msg.ParseFromString(frame)
                msgs.append(msg)
            except Exception as e:
                # drop one byte and re-sync (keep remaining frame bytes to salvage next frame)
                logger.debug("parse error — resync 1 byte")
                # put back tail to keep scanning
                buf[0:0] = frame[1:]
                continue
        return msgs

    # --- high-level send/recv ---
    def send_message(self, msg: ToEsp32):
        if not self.is_connected():
            raise RuntimeError("Not connected")
        self._write_framed(msg.SerializeToString())

    def listen(self):
        logger.debug("listen(): thread started")
        try:
            while self.running:
                try:
                    chunk = self.ser.read(4096)
                    if chunk:
                        self._rxbuf.extend(chunk)
                        self.bytes_rx += len(chunk)
                        for msg in self._feed_and_parse():
                            self.last_rx = time.monotonic()
                            if self.runtime is not None:
                                self.runtime.ingest(msg)
                            else:
                                logger.info(f"incoming msg: seq={getattr(msg,'seq',0)}")
                    else:
                        time.sleep(0.005)
                except (serial.SerialException, OSError) as e:
                    logger.error(f"Serial error: {e}")
                    break
                except struct.error as e:
                    logger.error(f"Framing error: {e}")
                except Exception as e:
                    logger.error(f"Unhandled listener exception: {e}")
        finally:
            self.running = False
            try:
                if self.ser and self.ser.is_open:
                    self.ser.close()
            except Exception:
                pass
            if self._on_down:
                try:
                    self._on_down()
                except Exception as e:
                    logger.debug(f"on_down callback error: {e}")
            logger.debug("listen(): thread exit")

    # --- convenience commands ---
    def send_ping(self, seq=None, return_seq=False):
        msg = ToEsp32()
        msg.seq = self._next_seq() if seq is None else int(seq)
        msg.ping.SetInParent()
        self.send_message(msg)
        return msg.seq if return_seq else None

    def send_get_settings(self, seq=None, return_seq=False):
        msg = ToEsp32()
        msg.seq = self._next_seq() if seq is None else int(seq)
        msg.get_settings.SetInParent()
        self.send_message(msg)
        return msg.seq if return_seq else None

    def send_set_settings(self, settings: SystemSettings, seq=None, return_seq=False):
        msg = ToEsp32()
        msg.seq = self._next_seq() if seq is None else int(seq)
        # copy fields from provided settings
        msg.set_settings.settings.current_signal_selection_state = bool(getattr(settings, "current_signal_selection_state", False))
        msg.set_settings.settings.action_state = max(0, min(3, int(getattr(settings, "action_state", 0))))
        self.send_message(msg)
        return msg.seq if return_seq else None

    def send_ping_1000x(self):
        logger.info("🚀 Starting 1000x ping test...")
        start = time.time()
        for i in range(1000):
            self.send_ping(seq=i+1)
            time.sleep(0.0005)
        dt = time.time() - start
        time.sleep(1.5)  # give listener a moment
        logger.info(f"✅ 1000 messages in {dt:.3f}s → {(1000/dt):.2f} Hz")
