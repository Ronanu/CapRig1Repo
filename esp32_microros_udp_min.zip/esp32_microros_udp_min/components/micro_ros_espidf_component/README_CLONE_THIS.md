# micro_ros_espidf_component missing

Clone the official component into this folder before building:

    git clone https://github.com/micro-ROS/micro_ros_espidf_component.git .